import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler

# Load dataset
data = pd.read_csv("dataset/german_credit_data.csv")

# Features and target
X = data.drop("kredit", axis=1)
y = data["kredit"]

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Scale data
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Train model
model = LogisticRegression(max_iter=2000)
model.fit(X_train, y_train)

print("\n💳 Credit Scoring System Ready!\n")

# ---------------- USER INPUT ----------------
print("Enter Customer Details:")

laufkont = int(input("Account Status (laufkont): "))
laufzeit = int(input("Loan Duration (laufzeit): "))
moral = int(input("Credit History (moral): "))
verw = int(input("Purpose (verw): "))
hoehe = int(input("Loan Amount (hoehe): "))
sparkont = int(input("Savings (sparkont): "))
beszeit = int(input("Employment Time (beszeit): "))
rate = int(input("Installment Rate (rate): "))
famges = int(input("Family Status (famges): "))
buerge = int(input("Guarantor (buerge): "))
wohnzeit = int(input("Residence Time (wohnzeit): "))
verm = int(input("Assets (verm): "))
alter = int(input("Age (alter): "))
weitkred = int(input("Other Credits (weitkred): "))
wohn = int(input("Housing (wohn): "))
bishkred = int(input("Existing Credits (bishkred): "))
beruf = int(input("Job (beruf): "))
pers = int(input("Persons (pers): "))
telef = int(input("Phone (telef): "))
gastarb = int(input("Foreign Worker (gastarb): "))

# Create input array
user_data = [[
    laufkont, laufzeit, moral, verw, hoehe, sparkont, beszeit,
    rate, famges, buerge, wohnzeit, verm, alter, weitkred,
    wohn, bishkred, beruf, pers, telef, gastarb
]]

# Scale input
user_data = scaler.transform(user_data)

# Prediction
prediction = model.predict(user_data)

print("\n---------------- RESULT ----------------")

if prediction[0] == 1:
    print("✅ Credit Approved (Low Risk Customer)")
else:
    print("❌ Credit Rejected (High Risk Customer)")