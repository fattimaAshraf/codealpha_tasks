import streamlit as st
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler

# Load dataset
data = pd.read_csv("dataset/german_credit_data.csv")

# Features and target
X = data.drop("kredit", axis=1)
y = data["kredit"]

# Train model
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

model = LogisticRegression(max_iter=2000)
model.fit(X_train, y_train)

# ---------------- UI ----------------
st.set_page_config(page_title="Credit Scoring System", page_icon="💳")

st.title("💳 Credit Scoring System")
st.write("Enter customer details to predict credit approval")

laufkont = st.number_input("Account Status (laufkont)", 1, 4)
laufzeit = st.number_input("Loan Duration (months)", 1, 72)
moral = st.number_input("Credit History (moral)", 1, 4)
verw = st.number_input("Purpose (verw)", 1, 10)
hoehe = st.number_input("Loan Amount", 0, 100000)
sparkont = st.number_input("Savings (sparkont)", 1, 5)
beszeit = st.number_input("Employment Time (beszeit)", 1, 5)
rate = st.number_input("Installment Rate (rate)", 1, 4)
famges = st.number_input("Family Status (famges)", 1, 4)
buerge = st.number_input("Guarantor (buerge)", 0, 2)
wohnzeit = st.number_input("Residence Time", 0, 50)
verm = st.number_input("Assets (verm)", 1, 4)
alter = st.number_input("Age", 18, 100)
weitkred = st.number_input("Other Credits (weitkred)", 0, 2)
wohn = st.number_input("Housing (wohn)", 1, 3)
bishkred = st.number_input("Existing Credits", 0, 10)
beruf = st.number_input("Job (beruf)", 1, 4)
pers = st.number_input("Persons", 1, 5)
telef = st.number_input("Phone (telef)", 0, 1)
gastarb = st.number_input("Foreign Worker (gastarb)", 0, 1)

if st.button("Predict Credit Status"):
    user_data = [[
        laufkont, laufzeit, moral, verw, hoehe, sparkont, beszeit,
        rate, famges, buerge, wohnzeit, verm, alter, weitkred,
        wohn, bishkred, beruf, pers, telef, gastarb
    ]]

    user_data = scaler.transform(user_data)
    prediction = model.predict(user_data)

    if prediction[0] == 1:
        st.success("✅ Credit Approved (Low Risk Customer)")
    else:
        st.error("❌ Credit Rejected (High Risk Customer)")