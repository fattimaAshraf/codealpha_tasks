import streamlit as st
import numpy as np
import tensorflow as tf
import cv2
from streamlit_drawable_canvas import st_canvas

# Load model
model = tf.keras.models.load_model("digit_model.h5")

st.set_page_config(page_title="AI Handwriting System", page_icon="✍️", layout="centered")

st.title("✍️ Production-Level Handwritten AI System")
st.write("Draw a digit below (0–9) and get real-time prediction")

# ---------------- CANVAS ----------------
canvas = st_canvas(
    fill_color="black",
    stroke_width=15,
    stroke_color="white",
    background_color="black",
    height=280,
    width=280,
    drawing_mode="freedraw",
    key="canvas",
)

# ---------------- PREPROCESS ----------------
def preprocess(img_array):

    img = cv2.resize(img_array.astype("uint8"), (28, 28))

    # invert (important for MNIST)
    img = 255 - img

    # normalize
    img = img / 255.0

    img = img.reshape(1, 28, 28, 1)

    return img


# ---------------- PREDICTION ----------------
if canvas.image_data is not None:

    img_array = canvas.image_data[:, :, 0]

    if st.button("Predict Digit"):

        processed = preprocess(img_array)

        prediction = model.predict(processed)[0]

        result = np.argmax(prediction)
        confidence = np.max(prediction)

        st.markdown("---")

        if confidence < 0.5:
            st.warning("⚠ Low confidence — try clearer drawing")

        st.success(f"Predicted Digit: {result}")
        st.info(f"Confidence: {confidence * 100:.2f}%")

        # Top 3 predictions
        st.write("### Top Predictions")
        top_3 = np.argsort(prediction)[-3:][::-1]

        for i in top_3:
            st.write(f"Digit {i} → {prediction[i]*100:.2f}%")

        st.bar_chart(prediction)