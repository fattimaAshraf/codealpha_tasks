import streamlit as st
import numpy as np
import tensorflow as tf
from PIL import Image, ImageOps
import cv2

# Load model
model = tf.keras.models.load_model("digit_model.h5")

# ---------------- UI DESIGN ----------------
st.set_page_config(page_title="AI Handwritten Recognition", page_icon="✍️", layout="centered")

st.markdown("<h1 style='text-align: center;'>✍️ Handwritten AI Recognition</h1>", unsafe_allow_html=True)
st.write("Upload a digit image or sketch input → AI will predict it instantly")

file = st.file_uploader("Upload Image", type=["png", "jpg", "jpeg"])


# ---------------- IMAGE PREPROCESSING ----------------
def preprocess_image(img):

    img = Image.open(file).convert("L")

    # invert (MNIST style)
    img = ImageOps.invert(img)

    # convert to numpy
    img = np.array(img)

    # resize bigger first (helps quality)
    img = cv2.resize(img, (200, 200))

    # threshold (clean noise)
    _, img = cv2.threshold(img, 120, 255, cv2.THRESH_BINARY)

    # find contours (digit detection)
    contours, _ = cv2.findContours(img, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    if len(contours) > 0:
        x, y, w, h = cv2.boundingRect(contours[0])
        img = img[y:y+h, x:x+w]

    # final resize to MNIST format
    img = cv2.resize(img, (28, 28))

    # normalize
    img = img / 255.0

    # reshape
    img = img.reshape(1, 28, 28, 1)

    return img


# ---------------- PREDICTION ----------------
if file is not None:

    st.image(file, caption="Uploaded Image", use_container_width=True)

    img = preprocess_image(file)

    prediction = model.predict(img)[0]

    result = np.argmax(prediction)
    confidence = np.max(prediction)

    # ---------------- OUTPUT ----------------
    st.markdown("---")

    if confidence < 0.5:
        st.warning("⚠ Low confidence prediction — image unclear")

    st.success(f"Predicted Digit: {result}")
    st.info(f"Confidence: {confidence * 100:.2f}%")

    # Top 3 predictions (VERY IMPORTANT FOR PROFESSIONAL LOOK)
    top_3 = np.argsort(prediction)[-3:][::-1]

    st.write("### 🔍 Top Predictions")

    for i in top_3:
        st.write(f"Digit {i} → {prediction[i]*100:.2f}%")

    # bar chart
    st.bar_chart(prediction)